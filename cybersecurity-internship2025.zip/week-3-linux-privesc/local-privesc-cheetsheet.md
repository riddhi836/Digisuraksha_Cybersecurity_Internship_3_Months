 🛡️ Local Privilege Escalation Cheatsheet  
**Author:** Shraddha Mishra  
**Date:** 22 July 2025  
**Focus:** Windows & Linux Enumeration and Exploitation  