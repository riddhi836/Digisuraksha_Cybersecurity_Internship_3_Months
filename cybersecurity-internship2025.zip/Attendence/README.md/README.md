# Attendance System - Instructions

## Intern: shraddha mishra

To mark weekly attendance:
1. Attend the session
2. Complete at least ONE flag
3. Upload a screenshot proof: `!![shraddha mishra](shraddhamishra_FlagX_Desc.jpg)

## Flags:
- Flag 1: Enter Flag ✅
- Flag 2: Blur Mode On ✅
- Flag 3: LinkedIn Post 
- Flag 4: Social Media Story/Post

